# git-remote-add
git remote add origin https://github.com/budi883/git-remote.git
